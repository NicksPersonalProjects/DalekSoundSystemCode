/*
 * DalekBoardInit.h
 *
 *  Created on: Jun 19, 2025
 *      Author: nicho
 */


#ifndef SRC_DALEKBOARDINIT_H_
#define SRC_DALEKBOARDINIT_H_

//Duty Cycle Thresholds
#define ThemeThreshold        8 //Input 1
#define LightsThreshold       8 //Input 2
#define ExterminateThreshold  8 //Input 3
#define BlasterThreshold      8 //Input 4

#define RGBDimmer			  100 //percentage, max 100

#define PrescalarValue 0
#define ARRValue 0xffff / (PrescalarValue + 1)

typedef enum Flag {HIGH,LOW} Flag;

extern Flag DWThemeFlag, BlasterFlag, LightFlag, ExterminateFlag;
//extern Flag DWThemeFlag = LOW, BlasterFlag = LOW, LightFlag = LOW, ExterminateFlag = LOW;

void TimersInit(void);
void FlagChecker(void);
void RGBColor(uint16_t Red, uint16_t Green, uint16_t Blue);
void ColorChanger(uint16_t RedStart, uint16_t GreenStart, uint16_t BlueStart, uint16_t RedFinish, uint16_t GreenFinish, uint16_t BlueFinish, uint16_t Steps);

#endif /* SRC_DALEKBOARDINIT_H_ */
